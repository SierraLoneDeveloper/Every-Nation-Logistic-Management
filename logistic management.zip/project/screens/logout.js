const HandleLogout = async () => {
      try {

      const data = 'Logout';
     
      if (data === "Logout") {
        await logout(); // Update auth state
        navigation.navigate('Login'); // Redirect to App screen
      } 
    } catch (error) {
      console.error('Error:', error); 
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
};

export default HandleLogout;
