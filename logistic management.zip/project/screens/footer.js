// components/Footer.js
import React from 'react';
import { View, TouchableOpacity, Text, Platform } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'; 
import globalStyle from '../styles/dbStyles'; // Adjust the import path as necessary

const Footer = ({ navigation }) => {
  return (
    <View style={[
      globalStyle.displayFlexFooter, 
      Platform.OS === 'android' ? globalStyle.andriodPadding : {}
    ]}>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('App')}>
        <Icon name="plus" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>Dashboard</Text>
      </TouchableOpacity>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('Assets')}>
        <Icon name="book" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>Assets</Text>
      </TouchableOpacity>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('Students')}>
        <Icon name="user" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>Students</Text>
      </TouchableOpacity>
      <TouchableOpacity style={globalStyle.footerBox} onPress={() => navigation.navigate('Finance')}>
        <Icon name="money" size={20} color="#000" />
        <Text style={globalStyle.footerBoxText}>finance</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Footer;