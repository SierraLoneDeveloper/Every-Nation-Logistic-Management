import React, {useState, useEffect} from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, Dimensions, StatusBar, TouchableOpacity, Alert } from 'react-native';
import { PieChart } from 'react-native-chart-kit'; 
import styles from '../styles/dbStyles';
import Icon from 'react-native-vector-icons/FontAwesome'; 
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const Finance = ({ navigation }) => {
  const [totalFinance, setTotalFinance] = useState(0);
  const [totalSpending, setTotalSpending] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const finance = await fetch('http://e3.myartsonline.com/fetch_transaction.php');
      const resultFinance = await finance.json();
      setTotalFinance(resultFinance.total);
      const spending = await fetch('http://e3.myartsonline.com/money.php');
      const result = await spending.json();

      const data = result[0]; // Access the first (and likely only) element in the array

      // Map the fetched data to match the PieChart format
      const colors = ['#ff6384', '#36a2eb']; // Colors for male and female

      const formattedTrends = [
        {
          name: 'Income',
          population: parseInt(data.income, 10), // Convert string to integer
          color: colors[0], // Color for males
        },
        {
          name: 'Expense',
          population: parseInt(data.expense, 10), // Convert string to integer
          color: colors[1], // Color for females
        },
      ];
      setTotalSpending(formattedTrends);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? styles.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>Finance</Text>
          <TouchableOpacity style={globalStyle.plusBtn} onPress={() => navigation.navigate('NewFinance')}>
            <Icon name="plus" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={globalStyle.textTitleView}>
          <Text style={globalStyle.textTitle}>Finance Overview</Text>
          <View style={globalStyle.overView}>
            <Text style={globalStyle.textTitleSmall}>Total</Text>
            <Text style={globalStyle.currency}>${totalFinance}</Text>
          </View>
          <Text style={globalStyle.textTitleSmall}>Finance in Category</Text>
          <PieChart
            data={totalSpending}
            width={Platform.OS === 'android' ? Dimensions.get('window').width - 20 : Dimensions.get('window').width}
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>State</Text>
            <Text style={globalStyle.textTitleSmall}>Amount</Text>
          </View>
          {totalSpending.map((item, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{item.name}</Text>
              <Text style={globalStyle.displayText}>{item.population}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
       <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default Finance;