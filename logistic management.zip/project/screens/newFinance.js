import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles
import { useAuth } from './AuthContext'; // Import Auth context

const NewFinance = ({ navigation }) => {
  const [transactionType, setTransactionType] = useState(""); // Renamed variable for clarity
  const [amount, setAmount] = useState(""); // Renamed variable for clarity
  const [source, setSource] = useState(""); // Renamed variable for clarity

  const { login } = useAuth(); // Ensure you get the login function from context

  const handleSaveData = async () => {
    try {
      const response = await fetch('http://e3.myartsonline.com/transaction.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `transactionType=${encodeURIComponent(transactionType)}&amount=${encodeURIComponent(amount)}&source=${encodeURIComponent(source)}`,
      });

      

      const data = await response.json();

      if (data.message === "Transaction recorded successfully.") {
        
        Alert.alert("Transaction is Successfully");
      } else {
        Alert.alert("Error", data.message || "Failed to save data.");
      }
    } catch (error) {
      Alert.alert("Transaction failed due to an invalid command!");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Finance Entry</Text>
      <TextInput
        style={styles.input}
        placeholder="Income or Expense"
        value={transactionType}
        onChangeText={setTransactionType}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Amount"
        value={amount}
        onChangeText={setAmount}
        placeholderTextColor="#888"
        keyboardType="numeric" // Ensure numeric input for amount
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Source of Income/Expense"
        value={source}
        onChangeText={setSource}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleSaveData}>
        <Text style={styles.buttonText}>Save Data</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewFinance;