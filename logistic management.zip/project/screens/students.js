import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  SafeAreaView,
  Platform,
  Dimensions,
  StatusBar,
  TouchableOpacity,
} from 'react-native';
import { PieChart } from 'react-native-chart-kit';
import styles from '../styles/dbStyles';
import Icon from 'react-native-vector-icons/FontAwesome';
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const Students = ({ navigation }) => {
  const [totalStudents, setTotalStudents] = useState(0);
  const [maleStudents, setMaleStudents] = useState(0);
  const [femaleStudents, setFemaleStudents] = useState(0);
  const [students, setStudents] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {

      // Fetch total students from data.php
      const totalResponse = await fetch('http://e3.myartsonline.com/data.php');
      const totalData = await totalResponse.json();
      setTotalStudents(totalData.total);

      // Fetch total boys from boy.php
      const boysResponse = await fetch('http://e3.myartsonline.com/boy.php');
      const boysData = await boysResponse.json();
      setMaleStudents(boysData.total); // Update male students count

      // Fetch total girls from girl.php
      const girlsResponse = await fetch('http://e3.myartsonline.com/girl.php');
      const girlsData = await girlsResponse.json();
      setFemaleStudents(girlsData.total); // Update female students count

      const studentResponse = await fetch('http://e3.myartsonline.com/students.php');
      const studentData = await studentResponse.json();

      // Assuming studentData is an array with a single object
      const data = studentData[0]; // Access the first (and likely only) element in the array

      // Map the fetched data to match the PieChart format
      const colors = ['#ff6384', '#36a2eb']; // Colors for male and female

      const formattedTrends = [
        {
          name: 'Male',
          population: parseInt(data.boys, 10), // Convert string to integer
          color: colors[0], // Color for males
        },
        {
          name: 'Female',
          population: parseInt(data.girls, 10), // Convert string to integer
          color: colors[1], // Color for females
        },
      ];
      // Set the formatted data for the PieChart
      setStudents(formattedTrends);
     
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };
  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView
        contentContainerStyle={
          Platform.OS === 'android' ? styles.andriodStyle : {}
        }
        style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}>
          <Text style={globalStyle.title}>Students</Text>
          <TouchableOpacity
            style={globalStyle.plusBtn}
            onPress={() => navigation.navigate('NewStudent')}>
            <Icon name="plus" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={globalStyle.textTitleView}>
          <Text style={globalStyle.textTitle}>Students Overview</Text>
          <View style={globalStyle.overView}>
            <Text style={globalStyle.textTitleSmall}>Total Student's</Text>
            <Text style={globalStyle.currency}>{totalStudents}</Text>
          </View>
          <Text style={globalStyle.textTitleSmall}>Student Per Category</Text>
          <PieChart
            data={students}
            width={
              Platform.OS === 'android'
                ? Dimensions.get('window').width - 20
                : Dimensions.get('window').width
            }
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Students</Text>
            <Text style={globalStyle.textTitleSmall}>Totals</Text>
          </View>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.displayText}>Total Students</Text>
            <Text style={globalStyle.displayText}>{totalStudents}</Text>
          </View>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.displayText}>Male</Text>
            <Text style={globalStyle.displayText}>{maleStudents}</Text>
          </View>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.displayText}>Female</Text>
            <Text style={globalStyle.displayText}>{femaleStudents}</Text>
          </View>
        </View>
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default Students;
