import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, Dimensions, StatusBar, TouchableOpacity } from 'react-native';
import { PieChart } from 'react-native-chart-kit'; 
import globalStyle from '../styles/dbStyles';
import Footer from './footer';
import Icon from 'react-native-vector-icons/FontAwesome';

const App = ({ navigation }) => {
  const [totalAssets, setTotalAssets] = useState(0);
  const [totalFinance, setTotalFinance] = useState(0);
  const [totalStudents, setTotalStudents] = useState(0);
  const [spendingTrends, setSpendingTrends] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {

      //Fetch total Balance from transaction.php
       const financeResponse = await fetch('http://e3.myartsonline.com/fetch_transaction.php');
      const totalFinances = await financeResponse.json();
      setTotalFinance(totalFinances.total);

      //Fetch total assets from total_assets.php
      const assetsResponse = await fetch('http://e3.myartsonline.com/total_assets.php');
      const totalAsset = await assetsResponse.json();
      setTotalAssets(totalAsset.total);
      
      // Fetch total students from data.php
     const totalResponse = await fetch('http://e3.myartsonline.com/data.php');
      const totalData = await totalResponse.json();
      setTotalStudents(totalData.total);

      // Fetch spending trends from expense.php
      const trendsResponse = await fetch('http://e3.myartsonline.com/expense.php');
      const trendsData = await trendsResponse.json();


      // Map the fetched data to match the PieChart format
      const colors = ['#ff6384', '#36a2eb', '#ffce56', '#4bc0c0', '#9966ff', '#ff9f40'];

      const formattedTrends = trendsData.map((item, index) => ({
        name: item.name,
        population: item.amount, 
        color: colors[index % colors.length], // Cycle through colors
      }));


      
      // Example spending trends (replace with actual logic if needed)
      setSpendingTrends(formattedTrends);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? globalStyle.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>Dashboard</Text>
          <TouchableOpacity
            style={globalStyle.plusBtn}
            onPress={() => navigation.navigate('HandleLogout')}>
            <Icon name="sign-out" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={globalStyle.textTitleView}>
          <Text style={globalStyle.textTitle}>Financial Overview</Text>
          <View style={globalStyle.overView}> 
            <Text style={globalStyle.textTitleSmall}>Total Spend This Month</Text>
            <Text style={globalStyle.currency}>${totalFinance}</Text>
          </View>
          <Text style={globalStyle.textTitleSmall}>Spending Trends</Text>
          <PieChart 
            data={spendingTrends}
            width={Platform.OS === 'android' ? Dimensions.get('window').width - 20 : Dimensions.get('window').width}
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Assets</Text>
            <Text style={globalStyle.textTitleSmall}>Recent Purchases</Text>
          </View>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.displayText}>Total Assets</Text>
            <Text style={globalStyle.displayText}>{totalAssets}</Text>
          </View>
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}> 
            <Text style={globalStyle.textTitleSmall}>Students</Text>
            <Text style={globalStyle.textTitleSmall}>Totals</Text>
          </View>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.displayText}>Total Students</Text>
            <Text style={globalStyle.displayText}>{totalStudents}</Text>
          </View>
        </View>
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default App;