import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, SafeAreaView, Platform, Dimensions, StatusBar, TouchableOpacity } from 'react-native';
import { PieChart } from 'react-native-chart-kit'; 
import styles from '../styles/dbStyles';
import Icon from 'react-native-vector-icons/FontAwesome'; 
import globalStyle from '../styles/dbStyles';
import Footer from './footer';

const Assets = ({ navigation }) => {
  const [totalAssets, setTotalAssets] = useState(0);
  const [spendingTrends, setSpendingTrends] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Fetch total assets from total_assets.php
      const assetsResponse = await fetch('http://e3.myartsonline.com/total_assets.php');
      const totalAsset = await assetsResponse.json();
      setTotalAssets(totalAsset.total);
      
      const assetFetch = await fetch('http://e3.myartsonline.com/all_assets.php');
      const totalFetched = await assetFetch.json();

      // Map the fetched data to match the PieChart format
      const colors = ['#ff6384', '#36a2eb', '#ffce56', '#4bc0c0', '#9966ff', '#ff9f40'];

      const formattedTrends = totalFetched.map((item, index) => ({
        name: item.name,
        population: parseInt(item.quantity, 10),
        color: colors[index % colors.length], // Cycle through colors
      }));

      setSpendingTrends(formattedTrends);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <SafeAreaView style={globalStyle.container}>
      <StatusBar barStyle="dark-content" backgroundColor="#f6f6f6" />
      <ScrollView contentContainerStyle={Platform.OS === 'android' ? styles.andriodStyle : {}} style={globalStyle.paddingScrollView}>
        <View style={globalStyle.displayCol}> 
          <Text style={globalStyle.title}>Assets</Text>
          <TouchableOpacity style={globalStyle.plusBtn} onPress={() => navigation.navigate('NewAsset')}>
            <Icon name="plus" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
        <View style={globalStyle.textTitleView}>
          <Text style={globalStyle.textTitle}>Assets Overview</Text>
          <View style={globalStyle.overView}>
            <Text style={globalStyle.textTitleSmall}>Total Assets Owned</Text>
            <Text style={globalStyle.currency}>{totalAssets}</Text>
          </View>
          <Text style={globalStyle.textTitleSmall}>Assets Trends</Text>
          <PieChart
            data={spendingTrends}
            width={Platform.OS === 'android' ? Dimensions.get('window').width - 20 : Dimensions.get('window').width}
            height={220}
            chartConfig={{
              backgroundColor: '#fff',
              backgroundGradientFrom: '#f6f6f6',
              backgroundGradientTo: '#f6f6f6',
              color: (opacity = 1) => `rgba(0, 122, 255, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
            }}
            accessor="population"
            backgroundColor="#fff"
            paddingLeft="15"
            paddingRight="15"
            style={globalStyle.chart}
          />
        </View>
        <View style={globalStyle.textTitleView}>
          <View style={globalStyle.displayFlex}>
            <Text style={globalStyle.textTitleSmall}>Assets</Text>
            <Text style={globalStyle.textTitleSmall}>Recent Purchases</Text>
          </View>
          {spendingTrends.map((item, index) => (
            <View key={index} style={globalStyle.displayFlex}>
              <Text style={globalStyle.displayText}>{item.name}</Text>
              <Text style={globalStyle.displayText}>{item.population}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
      <Footer navigation={navigation} />
    </SafeAreaView>
  );
};

export default Assets;