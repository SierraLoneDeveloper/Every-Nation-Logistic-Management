import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, Alert } from "react-native";
import styles from "../styles/styles"; // Import styles
import { useAuth } from './AuthContext'; // Import Auth context

const NewAsset = ({ navigation }) => {
  const [assetName, setAssetName] = useState("");
  const [quantity, setQuantity] = useState("");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");

  const { login } = useAuth(); // Ensure you get the login function from context

  const handleSaveData = async () => {
    try {
      const response = await fetch('http://e3.myartsonline.com/assets.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `assetName=${encodeURIComponent(assetName)}&quantity=${encodeURIComponent(quantity)}&amount=${encodeURIComponent(amount)}&description=${encodeURIComponent(description)}`,
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      if (data.message === "Data saved successfully") {
        // Uncomment to update auth state
        // login(); 
        // Uncomment to redirect to App screen
        // navigation.navigate('App'); 
        Alert.alert("Saved Successfully");
      } else {
        Alert.alert("Error", data.message || "Failed to save data.");
      }
    } catch (error) {
      console.error('Error:', error);
      Alert.alert("Error", "An unexpected error occurred. Please try again.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>New Asset Entry</Text>
      <TextInput
        style={styles.input}
        placeholder="Asset Name"
        value={assetName}
        onChangeText={setAssetName}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Quantity"
        value={quantity}
        onChangeText={setQuantity}
        placeholderTextColor="#888"
        keyboardType="numeric"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Amount per item"
        value={amount}
        onChangeText={setAmount}
        placeholderTextColor="#888"
        keyboardType="decimal-pad"
        autoCapitalize="none"
      />
      <TextInput
        style={styles.input}
        placeholder="Description (optional)"
        value={description}
        onChangeText={setDescription}
        placeholderTextColor="#888"
        autoCapitalize="none"
      />
      <TouchableOpacity style={styles.button} onPress={handleSaveData}>
        <Text style={styles.buttonText}>Save Data</Text>
      </TouchableOpacity>
    </View>
  );
};

export default NewAsset; // Ensure NewAsset is exported